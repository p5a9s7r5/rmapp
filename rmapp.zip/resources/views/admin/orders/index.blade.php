@extends("layouts.plantilla")

@section("cabecera")

Administrador Pedidos ML

@endsection


@section("general")

<table>
<nav class="navbar navbar-light bg-light">
    {!! Form::open(['action' => 'AdminOrdersController@index', 'method' => 'GET', 'class' => 'form-inline']) !!}
    {!!Form::text('busqueda', null, ['class' => 'form-control mr-sm-2', 'placeholder' => 'Busqueda', 'aria-label' => 'Search'])!!}</td>
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    {!! Form::close() !!}
</nav>
</table> <br/>


<div>
<table width="1000" border="1" style="margin: 0 auto;">
    <thead>
    <tr height="50">
       <th>Id</th>
       <th>Nro Oferta</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Monto</th>
       <th>Pedido Profit</th>
       <th>Ver Datos</th>
    </tr>
    </thead>
 
    <tbody>
    @if($orders)
        @foreach($orders as $order)
            <tr height="50">
             <td>{{$order->pedidos_id}}</td>
             <td>{{$order->codigo_venta}}</td>
             <td>{{$order->seudonimo}}</td>
             <td>{{$order->nombre}}</td>
             <td>{{$order->titulo_publicacion}}</td>
             <td>{{$order->costo}}</td>
             <td>{{$order->pedido_profit}}</td>
             <td>{{link_to_route('orders.show', 'Ver Datos', $order->pedidos_id)}}</td>
            </tr>
        @endforeach
    @endif
    </tbody>
</table>
</div>

@endsection

@section("pie")

{{ $orders->links() }}

@endsection