<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Banco extends Model
{
    
    protected $fillable = [
        'banco', 'fecha', 'referencia', 'monto',  
    ];

}
