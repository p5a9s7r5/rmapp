

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('orders.index', 'Ver Pedidos')); ?>

</div>

Cargar Pedidos Profit

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table border="1">
    <tr height="50">
       <th>Nro Oferta</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Codigo Profit</th>
       <th>Cantidad</th>
       <th>Monto</th>
       <th>Fecha</th>
       <th>Estatus</th>
       <th>Pedido Profit</th>
       <th>Actualizar</th>
    </tr>

    <?php
    
        $i=1;

    ?>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($i==1): ?>

        <?php echo Form::model($order, ['method' => 'PUT', 'action' => ['AdminOrdersController@update', $order->pedidos_id]]); ?>


        <?php echo Form::token(); ?>


            <tr height="50">
             <td><?php echo Form::label('codigo_venta', $order->codigo_venta); ?></td>
             <td><?php echo Form::label('seudonimo', $order->seudonimo); ?></td>
             <td><?php echo Form::label('nombre', $order->nombre); ?></td>
             <td><?php echo Form::label('titulo_publicacion', $order->titulo_publicacion); ?></td>
             <td><?php echo Form::text('codigo_profit', $order->codigo_profit); ?></td>
             <td><?php echo Form::select('cantidad', [$order->cantidad => $order->cantidad], $order->cantidad); ?></td>
             <td><?php echo Form::label('costo', $order->costo); ?></td>
             <td><?php echo Form::label('fecha', $order->fecha); ?></td>
             <td><?php echo Form::select('estatus', ['Nuevo' => 'Nuevo', 'Pendiente' => 'Pendiente', 'Duplicado' => 'Duplicado', 'Agotado' => 'Agotado', 'Concretada' => 'Concretada', 'No Compra' => 'No Compra'], $order->estatus); ?></td>
             <td><?php echo Form::text('pedido_profit',$order->pedido_profit); ?></td>
             <td><?php echo Form::submit('Actualizar'); ?></td>
            </tr>

        <?php echo Form::close(); ?>




    <?php else: ?>

        <?php echo Form::model($order, ['method' => 'PUT', 'action' => ['AdminOrdersController@update', $order->pedidos_id]]); ?>


            <?php echo Form::token(); ?>


                <tr height="50">
                 <td><?php echo Form::label('codigo_venta', $order->codigo_venta); ?></td>
                 <td><?php echo Form::label('seudonimo', $order->seudonimo); ?></td>
                 <td><?php echo Form::label('nombre', $order->nombre); ?></td>
                 <td><?php echo Form::label('titulo_publicacion', $order->titulo_publicacion); ?></td>
                 <td><?php echo Form::text('codigo_profit', $order->codigo_profit); ?></td>
                 <td><?php echo Form::select('cantidad', [$order->cantidad => $order->cantidad], $order->cantidad); ?></td>
                 <td><?php echo Form::label('costo', $order->costo); ?></td>
                 <td><?php echo Form::label('fecha', $order->fecha); ?></td>
                 <td><?php echo Form::select('estatus', ['Nuevo' => 'Nuevo', 'Pendiente' => 'Pendiente', 'Duplicado' => 'Duplicado'], $order->estatus); ?></td>
                 <td><?php echo Form::text('pedido_profit',$order->pedido_profit); ?></td>
                 <td><?php echo Form::submit('Actualizar'); ?></td>
                </tr>

        <?php echo Form::close(); ?>


    <?php endif; ?>

    <?php
    
        $i++;

    ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/edit.blade.php ENDPATH**/ ?>