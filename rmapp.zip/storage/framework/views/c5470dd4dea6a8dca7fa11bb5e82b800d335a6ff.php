

<?php $__env->startSection("cabecera"); ?>

Formulario de Envio

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>


<?php echo Form::open(['method' => 'post', 'action' => 'FormsController@confirmship']); ?>


<table id="tabla2">
    <tr height="50">
       <th><?php echo Form::label('despacho', 'Empresa Envio'); ?></th>
       <td><?php echo Form::text('despacho', session()->get('despacho'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('despacho', session()->get('despacho')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('destinatario', 'Nombre Destinatario'); ?></th>
       <td><?php echo Form::text('destinatario', session()->get('destinatario'), ['required'=>'required', 'maxlength'=> 40, 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('cedula', 'Nro Cedula'); ?></th>
       <td><?php echo Form::text('cedula', session()->get('cedula'), ['required'=>'required', 'maxlength'=> 15, 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('telefono', 'Telefono'); ?></th>
       <td><?php echo Form::text('telefono', session()->get('telefono'), ['required'=>'required', 'maxlength'=> 25, 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('direccion_envio', 'Direccion'); ?></th>
       <td><?php echo Form::textarea('direccion_envio', session()->get('direccion_envio'), ['required'=>'required', 'maxlength'=> 300, 'rows' => 5, 'cols' => 55]); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('ciudad_envio', 'Ciudad / Estado'); ?></th>
       <td><?php echo Form::text('ciudad_envio', session()->get('ciudad_envio'), ['required'=>'required', 'maxlength'=> 30, 'class' => 'textarea2']); ?></td>
    </tr>
</table>
<br/>
<div>

<table style="margin: 0 auto;">

<tr height="50">
   <td><button type="button" onclick="history.back();" class="inputbutton">Volver</button></td>
   <th><?php echo Form::reset('Limpiar'); ?></th>
   <td><?php echo Form::submit('Aceptar'); ?></td>
</tr>

</table>

<?php echo Form::close(); ?>


</div>
<br/><br/>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/forms/ml2.blade.php ENDPATH**/ ?>