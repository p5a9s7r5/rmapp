

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('items.index', 'Regresar')); ?>

</div>

Datos Generales

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table id="tabla2">

    <tr height="50">
       <th>Id</th>
       <td><?php echo e($item->id); ?></td>
    </tr>
    <tr height="50">
       <th>Titulo Profit</th>
       <td><?php echo e($item->titulo); ?></td>
    </tr>
    <tr height="50">
       <th>Titulo ML</th>
       <td><?php echo e($item->nombre_ml); ?></td>
    </tr>
    <tr height="50">
       <th>Codigo Profit</th>
       <td><?php echo e($item->codigo_profit); ?></td>
    </tr>
    <tr height="50">
       <th>Stock Actual</th>
       <td><?php echo e($item->stock_general); ?></td>
    </tr>
    <tr height="50">
       <th>Stock Disponible</th>
       <td><?php echo e($item->stock_disponible); ?></td>
    </tr>
    <tr height="50">
       <th>Comprometido Temporal</th>
       <td><?php echo e($item->comprometido_temporal); ?></td>
    </tr>
    <tr height="50">
       <th>Precio $</th>
       <td><?php echo e($item->precio); ?></td>
    </tr>
    <tr height="50">
       <th>Codigo ML3</th>
       <td><?php echo e($item->ml3); ?></td>
    </tr>
    <tr height="50">
       <th>Variante ML3</th>
       <td><?php echo e($item->ml5); ?></td>
    </tr>
    <tr height="50">
       <th>Codigo ML4</th>
       <td><?php echo e($item->ml4); ?></td>
    </tr>
    <tr height="50">
       <th>Variante ML4</th>
       <td><?php echo e($item->variante_ml4); ?></td>
    </tr>
    <tr height="50">
       <th>Estatus ML</th>
       <td><?php echo e($item->estatus_ml); ?></td>
    </tr>
    <tr height="50">
       <th>Tiempo Activo (Minutos)</th>
       <td><?php echo e($item->tiempo_activo); ?></td>
    </tr>
    <tr height="50">
       <th>Ventas Activas</th>
       <td><?php echo e($item->vendidos_ml); ?></td>
    </tr>
    
</table>

<br/>

<div>
<table>

<input type ='button' class="btn btn-warning"  value = 'Actualizar' onclick="location.href = '<?php echo e(route('items.edit', $item->id)); ?>'"/>

</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/items/show.blade.php ENDPATH**/ ?>