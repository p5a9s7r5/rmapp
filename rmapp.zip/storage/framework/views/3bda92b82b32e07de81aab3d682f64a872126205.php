

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('users.index', 'Regresar')); ?>

</div>

Datos Generales

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table width="600" border="1">
    <tr>
       <th width="50">Id</th>
       <th width="200">Nombre</th>
       <th width="250">Email</th>
       <th>Acceso</th>
    </tr>

    <tr>
     <td><?php echo e($user->id); ?></td>
     <td><?php echo e($user->name); ?></td>
     <td><?php echo e($user->email); ?></td>
     <td><?php echo e($user->acceso); ?></td>
    </tr>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/users/show.blade.php ENDPATH**/ ?>