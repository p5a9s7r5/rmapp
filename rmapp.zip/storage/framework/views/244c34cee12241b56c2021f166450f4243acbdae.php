

<?php $__env->startSection("cabecera"); ?>

<img src="/images/logo.jpg" class="imgcabecera">

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<div class="informacion">

<table>
    <tr height="50">
       <th>Gracias por su información. Puede retirar por nuestra tienda de lunes a viernes de 9am a 12pm y 1pm a 4pm</th>
    </tr>

    <tr height="50">
       <br/>
    </tr>
    <tr height="50">
       <td>Urb. Los Caobos Av. Final Paseo Colon Res. Venezuela Edif. Tachira PB Local 1</td>
    </tr>
    <tr height="50">
       <td>Plaza de Venezuela, Caracas</td>
    </tr>
    <tr height="25">
       <br/>
    </tr>
    <tr height="50">
       <td>Referencia: Desde la redoma de Plaza Venezuela sigue direccion hacia el Edificio Polar</td>
    </tr>
    <tr height="50">
       <td>Luego del Edificio de CNE está la Sinagoga, seguido esta la entrada de las Res. Venezuela</td>
    </tr>
    <tr height="50">
       <td>Un porton verde a mano derecha antes de llegar al Parque Los Caobos. Identificarse en la vigilancia</td>
    </tr>
    <tr height="25">
        <br/>
    </tr>
    <tr height="50">
       <td>Ubicacion en Google Maps: <a href="https://goo.gl/maps/dqZgQG2Asky">Maps</a></td>
    </tr>
</table>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/forms/confirm1.blade.php ENDPATH**/ ?>