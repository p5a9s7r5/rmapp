

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('orders.index', 'Todos los Pedidos')); ?>

</div>

Pagos por Verificar

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>


<div>
<table id="tabla1">
    <thead>
    <tr height="50">
       <th>Despacho</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Monto</th>
       <th>Banco</th>
       <th>Pedido Profit</th>
       <th>Ver Informacion</th>
    </tr>
    </thead>
 
    <tbody>
    <?php if($orders): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($order->despacho); ?></td>
             <td><?php echo e($order->seudonimo); ?></td>
             <td><?php echo e($order->nombre); ?></td>
             <td><?php echo e($order->titulo_publicacion); ?></td>
             <td><?php echo e($order->costo); ?></td>
             <td><?php echo e($order->banco); ?></td>
             <td><?php echo e($order->pedido_profit); ?></td>
             <td><?php echo e(link_to_route('orders.paycheck', 'Ver Datos', $order->pedidos_id)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/payments.blade.php ENDPATH**/ ?>