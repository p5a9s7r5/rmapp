

<?php $__env->startSection("cabecera"); ?>

Ingresar Estados de Cuenta

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<?php echo Form::open(['url' => '/admin/banks' , 'method' => 'post', 'files' => true]); ?>


<table width="500" style="margin: 0 auto;">

    <tr height="50">
        <th><?php echo Form::label('id', 'Insertar Archivo Excel: '); ?></th>
        <td><?php echo Form::file('file'); ?></td>
    </tr>
    <tr height="50">
        <th><?php echo Form::reset('Borrar'); ?></th>
        <td><?php echo Form::submit('Insertar'); ?></td>
    </tr>
</table>
    <?php echo Form::close(); ?>

    



<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/banks/create.blade.php ENDPATH**/ ?>