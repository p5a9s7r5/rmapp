

<?php $__env->startSection("cabecera"); ?>

Administrador Articulos Profit

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table>
<nav class="navbar navbar-light bg-light">
    <?php echo Form::open(['action' => 'AdminItemsController@index', 'method' => 'GET', 'class' => 'form-inline']); ?>

    <?php echo Form::text('busqueda', null, ['class' => 'form-control mr-sm-2', 'placeholder' => 'Busqueda', 'aria-label' => 'Search']); ?></td>
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    <?php echo Form::close(); ?>

</nav>
</table> <br/>


<div>
<table width="1000" border="1" style="margin: 0 auto;">
    <thead>
    <tr height="50">
       <th>Id</th>
       <th>Codigo Profit</th>
       <th>Titulo</th>
       <th>Stock Disponible</th>
       <th>Ventas Activas</th>
       <th>Precio</th>
       <th>Codigo ML3</th>
       <th>Codigo ML4</th>
       <th>Datos</th>
    </tr>
    </thead>
 
    <tbody>
    <?php if($items): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($item->id); ?></td>
             <td><?php echo e($item->codigo_profit); ?></td>
             <td><?php echo e($item->titulo); ?></td>
             <td><?php echo e($item->stock_disponible); ?></td>
             <td><?php echo e($item->vendidos_ml); ?></td>
             <td><?php echo e($item->precio); ?></td>
             <td><?php echo e($item->ml3); ?></td>
             <td><?php echo e($item->ml4); ?></td>
             <td><?php echo e(link_to_route('items.show', 'Ver Datos', $item->id)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>

<?php echo e($items->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/items/index.blade.php ENDPATH**/ ?>