

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('users.index', 'Regresar')); ?>

</div>

Modificar Usuarios

<?php $__env->stopSection(); ?>

<?php $__env->startSection("general"); ?>

<?php echo Form::model($user, ['method' => 'PUT', 'action' => ['AdminUsersController@update', $user->id]]); ?>


    <?php echo Form::token(); ?>


    <table width="300">
        <tr>
        <td><?php echo Form::label('nombre', 'Nombre:'); ?></td>
        <td><?php echo Form::text('name'); ?></td>
        </tr>
        <tr>
        <td><?php echo Form::label('email', 'Email:'); ?></td>
        <td><?php echo Form::text('email'); ?></td>
        </tr>
        <tr>
        <td><?php echo Form::label('acceso', 'Acceso:'); ?></td>
        <td><?php echo Form::select('acceso', ['admin' => 'Admin', 'operaciones' => 'Operaciones', 'ventas' => 'Ventas'], 'ventas'); ?></td>
        </tr>
        <tr>
        <td><?php echo Form::submit('Actualizar'); ?></td>
        <td><?php echo Form::reset('Limpiar'); ?></td>
        </tr>
    </table>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>