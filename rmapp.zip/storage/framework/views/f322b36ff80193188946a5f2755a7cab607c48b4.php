

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('orders.payments', 'Volver')); ?>

</div>

Verificar Pago

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

    <table id="tabla1">
        <tr height="50">
            <h2>Cliente</h2>
            <th>Seudonimo:</th>
            <td><?php echo e($order->seudonimo); ?></td>
            <th>Nombre:</th>
            <td><?php echo e($order->nombre); ?></td>
            <th>Codigo Oferta:</th>
            <td><?php echo e($order->codigo_venta); ?></td>
        </tr>
    </table><br/><br/>

    <table id="tabla1">
        <tr height="50">
            <h2>Datos de Pago</h2>
            <th>Fecha</th>
            <th>Banco</th>
            <th>Banco Origen</th>
            <th>Monto</th>
            <th>Referencia</th>
            <th>Factura Profit</th>
            <th>Confirmar</th>
        </tr>

        <?php echo Form::model($order, ['method' => 'PUT', 'action' => ['AdminOrdersController@updatepay', $order->pedidos_id]]); ?>


        <tr height="50">
            <td><?php echo Form::date('fecha_pago', $order->fecha_pago, ['class' => 'textarea2']); ?></td>
            <td><?php echo Form::select('banco', config('options.bancos'), $order->banco, ['class' => 'textarea2']); ?></td>
            <td><?php echo Form::text('interbancario', $order->interbancario, ['class' => 'textarea2']); ?></td>
            <td><?php echo Form::text('monto_pago', $order->monto_pago, ['class' => 'textarea1']); ?></td>
            <td><?php echo Form::text('referencia_pago', $order->referencia_pago, ['class' => 'textarea2']); ?></td>
            <td><?php echo Form::text('factura_profit', $order->factura_profit, ['class' => 'textarea2']); ?></td>
            <td><?php echo Form::submit('Aprobar'); ?></td>
        </tr>
    </table><br/><br/>

        <?php echo Form::close(); ?>


    <table id="tabla1">
        <tr height="50">
            <h2>Datos Agregados</h2>
            <th class='textarea2'>Despacho</th>
            <th class='textarea2'>Articulo</th>
            <th class='textarea2'>Otros Articulos</th>
            <th class='textarea1'>Cantidad</th>
            <th class='textarea2'>Transferencias Adicionales</th>
        </tr>

        <tr height="50">
            <td><?php echo Form::label('despacho', $order->despacho, ['class' => 'textarea3']); ?></td>
            <td><?php echo Form::label('articulo_cliente', $order->articulo_cliente); ?></td>
            <td><?php echo Form::label('', $order->otros_articulos); ?></td>
            <td><?php echo Form::label('cantidad_cliente', $order->cantidad_cliente); ?></td>
            <td><?php echo Form::label('', $order->otros_pagos); ?></td>
        </tr>
    </table><br/><br/>

        <?php if($order->destinatario): ?>

        <table id="tabla1">
        <tr height="50">
            <h2>Datos de Envio</h2>
            <th class='textarea2'>Destinatario</th>
            <th class='textarea2'>Nro Cedula</th>
            <th class='textarea2'>Telefono</th>
            <th class='textarea3'>Direccion</th>
            <th class='textarea2'>Ciudad / Estado</th>
            <th class='textarea1'>Editar Datos</th>
        </tr>

        <tr height="50">
            <td><?php echo Form::label('destinatario', $order->destinatario); ?></td>
            <td><?php echo Form::label('cedula', $order->cedula); ?></td>
            <td><?php echo Form::label('telefono', $order->telefono); ?></td>
            <td><?php echo Form::label('direccion_envio', $order->direccion_envio); ?></td>
            <td><?php echo Form::label('ciudad_envio', $order->ciudad_envio); ?></td>
            <td><input type ='button' class="btn btn-warning"  value = 'Editar' onclick="location.href = '<?php echo e(route('orders.shipedit', $order->pedidos_id)); ?>'"/></td>
        </tr>
        </table><br/><br/>

        <?php endif; ?>

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <table id="tabla1">
        <tr height="50">
            <h2>Datos de Oferta</h2>
            <th>Nro Oferta</th>
            <th>Articulo</th>
            <th>Codigo Profit</th>
            <th>Cantidad</th>
            <th>Monto</th>
            <th>Fecha</th>
            <th>Estatus</th>
            <th>Pedido Profit</th>
        </tr>

        <tr height="50">
            <td><?php echo Form::label('codigo_venta', $ord->codigo_venta); ?></td>
            <td><?php echo Form::label('titulo_publicacion', $ord->titulo_publicacion); ?></td>
            <td><?php echo Form::label('codigo_profit', $ord->codigo_profit); ?></td>
            <td><?php echo Form::label('cantidad', $ord->cantidad); ?></td>
            <td><?php echo Form::label('costo', $ord->costo); ?></td>
            <td><?php echo Form::label('fecha', $ord->fecha); ?></td>
            <td><?php echo Form::label('estatus', $ord->estatus); ?></td>
            <td><?php echo Form::label('pedido_profit',$ord->pedido_profit, ['class' => 'textarea1']); ?></td>
        </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/paycheck.blade.php ENDPATH**/ ?>