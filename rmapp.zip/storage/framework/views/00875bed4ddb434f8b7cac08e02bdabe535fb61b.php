

<?php $__env->startSection("cabecera"); ?>

Confirmar Datos

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>


<?php echo Form::open(['method' => 'post', 'action' => 'FormsController@pay']); ?>


<table id="tabla2">

    <tr height="50">
       <th><?php echo Form::label('seudonimo', 'Seudonimo'); ?></th>
       <td><?php echo Form::text('seudonimo', session()->get('seudonimo'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('seudonimo', session()->get('seudonimo')); ?>

           <?php echo Form::hidden('pedidos_id', session()->get('pedidos_id')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('articulo_cliente', 'Articulo Comprado'); ?></th>
       <td><?php echo Form::text('articulo_cliente', session()->get('articulo_cliente'), ['disabled' => 'disabled', 'class' => 'textarea3']); ?></td>
           <?php echo Form::hidden('articulo_cliente', session()->get('articulo_cliente')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('otros_articulos', 'Articulos Adicionales'); ?></th>
       <td><?php echo Form::textarea('otros_articulos', session()->get('otros_articulos'), ['disabled' => 'disabled', 'rows' => 3, 'cols' => 55]); ?></td>
           <?php echo Form::hidden('otros_articulos', session()->get('otros_articulos')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('cantidad_cliente', 'Total articulos'); ?></th>
       <td><?php echo Form::number('cantidad_cliente', session()->get('cantidad_cliente'), ['disabled' => 'disabled', 'class' => 'textarea1']); ?></td>
           <?php echo Form::hidden('cantidad_cliente', session()->get('cantidad_cliente')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('fecha_pago', 'Fecha Transferencia'); ?></th>
       <td><?php echo Form::date('fecha_pago', session()->get('fecha_pago'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('fecha_pago', session()->get('fecha_pago')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('banco', 'Banco'); ?></th>
       <td><?php echo Form::text('banco', session()->get('banco'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('banco', session()->get('banco')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('interbancario', 'Banco Origen'); ?></th>
       <td><?php echo Form::text('interbancario', session()->get('interbancario'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('interbancario', session()->get('interbancario')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('monto_pago', 'Monto'); ?></th>
       <td><?php echo Form::text('monto_pago', session()->get('monto_pago'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('monto_pago', session()->get('monto_pago')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('referencia_pago', 'Numero Referencia'); ?></th>
       <td><?php echo Form::text('referencia_pago', session()->get('referencia_pago'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('referencia_pago', session()->get('referencia_pago')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('otros_pagos', 'Transferencias Adicionales'); ?></th>
       <td><?php echo Form::textarea('otros_pagos', session()->get('otros_pagos'), ['disabled' => 'disabled', 'rows' => 2, 'cols' => 55]); ?></td>
           <?php echo Form::hidden('otros_pagos', session()->get('otros_pagos')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('email', 'Email'); ?></th>
       <td><?php echo Form::text('email', session()->get('email'), ['disabled' => 'disabled', 'class' => 'textarea3']); ?></td>
           <?php echo Form::hidden('email', session()->get('email')); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('despacho', 'Despacho'); ?></th>
       <td><?php echo Form::text('despacho', session()->get('despacho'), ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('despacho', session()->get('despacho')); ?>

    </tr>    
</table>
<br/>
<div>

<table style="margin: 0 auto;">

<tr height="50">
    <td><button type="button" onclick="history.back();" class="inputbutton">Volver</button></td>
   <td><?php echo Form::submit('Confirmar'); ?></td>
</tr>

</table>

<?php echo Form::close(); ?>


</div>
<br/><br/>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/forms/confirmpay.blade.php ENDPATH**/ ?>