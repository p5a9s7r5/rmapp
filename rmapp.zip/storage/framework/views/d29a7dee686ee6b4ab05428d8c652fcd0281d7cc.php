

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('users.index', 'Regresar')); ?>

</div>

Eliminar Usuario

<?php $__env->stopSection(); ?>

<?php $__env->startSection("general"); ?>

<?php echo Form::open(['method' => 'DELETE', 'action' => ['AdminUsersController@destroy', $user->id]]); ?>


        <?php echo Form::token(); ?>


<table width="300" border="1">
        <tr>
        <td>Id:</td>
        <td><?php echo e($user->id); ?></td>
        </tr>
        <tr>
        <td>Nombre:</td>
        <td><?php echo e($user->name); ?></td>
        </tr>
        <tr>
        <td>Email:</td>
        <td><?php echo e($user->email); ?></td>
        </tr>
        <tr>
        <td>Acceso:</td>
        <td><?php echo e($user->acceso); ?></td>
        </tr>
</table>
        <br>

        <?php echo Form::submit('Eliminar'); ?>


        <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/users/delete.blade.php ENDPATH**/ ?>