

<?php $__env->startSection("cabecera"); ?>

Cargar Pedidos Profit

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table border="1">
    <tr height="50">
       <th>Nro Oferta</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Variacion</th>
       <th>Monto</th>
       <th>Pedido Profit</th>
       <th>Actualizar</th>
    </tr>
 
    <?php if($orders): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php echo Form::model($order, ['method' => 'post', 'action' => ['AdminOrdersController@update', $order->pedido_id]]); ?>


        <?php echo Form::token(); ?>

        <?php echo method_field('PUT'); ?>

            <tr height="50">
             <td><?php echo Form::label('codigo_venta', $order->codigo_venta); ?></td>
             <td><?php echo Form::label('seudonimo', $order->seudonimo); ?></td>
             <td><?php echo Form::label('nombre', $order->nombre); ?></td>
             <td><?php echo Form::label('titulo_publicacion', $order->titulo_publicacion); ?></td>
             <td><?php echo Form::label('variacion_nombre', $order->variacion_nombre); ?></td>
             <td><?php echo Form::label('costo', $order->costo); ?></td>
             <td><?php echo Form::text('pedido_profit',''); ?></td>
             <td><?php echo Form::submit('Cargar'); ?></td>
            </tr>

        <?php echo Form::close(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/create.blade.php ENDPATH**/ ?>