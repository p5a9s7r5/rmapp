

<?php $__env->startSection("cabecera"); ?>

Administrador Usuarios

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table width="1000" border="1" style="margin: 0 auto;">
    <tr height="50">
       <th width="50">Id</th>
       <th width="200">Nombre</th>
       <th width="250">Email</th>
       <th>Acceso</th>
       <th>Datos</th>
       <th>Actualizar</th>
       <th>Eliminar</th>
    </tr>
 
    <?php if($users): ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($user->id); ?></td>
             <td><?php echo e($user->name); ?></td>
             <td><?php echo e($user->email); ?></td>
             <td><?php echo e($user->acceso); ?></td>
             <td><?php echo e(link_to_route('users.show', 'Ver Datos', $user->id)); ?></td>
             <td><?php echo e(link_to_route('users.edit', 'Modificar Usuario', $user->id)); ?></td>
             <td><a href="users/<?php echo e($user->id); ?>/delete">Eliminar Usuario</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/users/index.blade.php ENDPATH**/ ?>