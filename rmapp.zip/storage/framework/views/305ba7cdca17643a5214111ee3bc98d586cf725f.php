

<?php $__env->startSection("cabecera"); ?>

Formulario de Pagos

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>


<?php echo Form::open(['method' => 'post', 'action' => 'FormsController@confirmpay']); ?>


<table id="tabla2">

    <tr height="50">
       <th><?php echo Form::label('seudonimo', 'Seudonimo'); ?></th>
       <td><?php echo Form::text('seudonimo', $order->seudonimo, ['disabled' => 'disabled', 'class' => 'textarea2']); ?></td>
           <?php echo Form::hidden('seudonimo', $order->seudonimo); ?>

           <?php echo Form::hidden('pedidos_id', $order->pedidos_id); ?>

           <?php echo Form::hidden('ciudad_envio', $order->ubicacion); ?>

           <?php echo Form::hidden('telefono', $order->telefono); ?>

           <?php echo Form::hidden('destinatario', $order->nombre); ?>

    </tr>
    <tr height="50">
       <th><?php echo Form::label('articulo', 'Articulo Comprado'); ?></th>
       <td><?php echo Form::text('articulo_cliente', $order->titulo_publicacion, ['required'=>'required', 'maxlength'=> 80, 'class' => 'textarea3']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('otrosa', 'Compras Articulos Adicionales? '); ?></th>
       <td><input type="radio" name="hab1" onclick="otros_articulos.disabled=false" />Si 
           <input type="radio" name="hab1" onclick="otros_articulos.disabled=true" checked="checked"/>No</td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('otros_articulos', 'Articulos Adicionales'); ?></th>
       <td><?php echo Form::textarea('otros_articulos', session()->get('otros_articulos'), ['disabled' => 'disabled', 'maxlength'=> 300, 'rows' => 4, 'cols' => 55]); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('cantidad_cliente', 'Total articulos'); ?></th>
       <td><?php echo Form::number('cantidad_cliente', $order->cantidad, ['required'=>'required', 'class' => 'textarea1']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('fecha_pago', 'Fecha Transferencia'); ?></th>
       <td><?php echo Form::date('fecha_pago', session()->get('fecha_pago'), ['required'=>'required', 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('banco', 'Banco'); ?></th>
       <td><?php echo Form::select('banco', config('options.bancos'), session()->get('banco'), ['required'=>'required', 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('otrobanco', 'La Trasnferencia se realizo desde otro Banco?'); ?></th>
       <td><input type="radio" name="hab2" onclick="interbancario.disabled=false" />Si 
           <input type="radio" name="hab2" onclick="interbancario.disabled=true" checked="checked"/>No
    </tr>
    <tr height="50">
       <th><?php echo Form::label('interbancario', 'Banco Origen'); ?></th>
       <td><?php echo Form::text('interbancario', session()->get('interbancario'), ['disabled' => 'disabled', 'maxlength'=> 20, 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('monto_pago', 'Monto'); ?></th>
       <td><?php echo Form::text('monto_pago', $order->costo, ['required'=>'required', 'maxlength'=> 20, 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('referencia_pago', 'Numero Referencia'); ?></th>
       <td><?php echo Form::text('referencia_pago', session()->get('referencia_pago'), ['required'=>'required', 'maxlength'=> 30, 'class' => 'textarea2']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('otrast', 'Realizaste mas de una transferencia? '); ?></th>
       <td><input type="radio" name="hab3" onclick="otrastr.disabled=false" />Si 
           <input type="radio" name="hab3" onclick="otrastr.disabled=true" checked="checked"/>No</td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('otros_pagos', 'Datos Transferencias Adicionales'); ?></th>
       <td><?php echo Form::textarea('otros_pagos', session()->get('otros_pagos'), ['disabled' => 'disabled', 'maxlength'=> 300, 'rows' => 3, 'cols' => 55]); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('email', 'Email'); ?></th>
       <td><?php echo Form::email('email', session()->get('email'), ['required'=>'required', 'class' => 'textarea3']); ?></td>
    </tr>
    <tr height="50">
       <th><?php echo Form::label('despacho', 'Despacho'); ?></th>
       <td><?php echo Form::select('despacho', config('options.despachos'), session()->get('despacho'), ['required'=>'required', 'class' => 'textarea2']); ?></td>
    </tr>    
</table>
<br/>
<div>

<table style="margin: 0 auto;">

<tr height="50">
   <th><?php echo Form::reset('Limpiar'); ?></th>
   <td><?php echo Form::submit('Aceptar'); ?></td>
</tr>

</table>

<?php echo Form::close(); ?>


</div>
<br/><br/>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/forms/ml.blade.php ENDPATH**/ ?>