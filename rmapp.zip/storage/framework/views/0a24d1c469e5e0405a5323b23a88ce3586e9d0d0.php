

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('orders.index', 'Regresar')); ?>

</div>

Datos Generales

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table id="tabla3">

    <tr height="50">
       <th></th>
       <th>Datos Pedido</th>
    </tr>
    <tr height="50">
       <th>Id</th>
       <td><?php echo e($order->pedidos_id); ?></td>
    </tr>
    <tr height="50">
       <th>Nro Oferta</th>
       <td><?php echo e($order->codigo_venta); ?></td>
    </tr>
    <tr height="50">
       <th>Seudonimo</th>
       <td><?php echo e($order->seudonimo); ?></td>
    </tr>
    <tr height="50">
       <th>Nombre</th>
       <td><?php echo e($order->nombre); ?></td>
    </tr>
    <tr height="50">
       <th>Telefono</th>
       <td><?php echo e($order->telefono); ?></td>
    </tr>
    <tr height="50">
       <th>Ubicacion</th>
       <td><?php echo e($order->ubicacion); ?></td>
    </tr>
    <tr height="50">
       <th>Articulo</th>
       <td><?php echo e($order->titulo_publicacion); ?></td>
    </tr>
    <tr height="50">
       <th>Codigo Profit</th>
       <td><?php echo e($order->codigo_profit); ?></td>
    </tr>
    <tr height="50">
       <th>Variacion</th>
       <td><?php echo e($order->variacion_nombre); ?></td>
    </tr>
    <tr height="50">
       <th>Costo</th>
       <td><?php echo e($order->costo); ?></td>
    </tr>
    <tr height="50">
       <th>Cantidad</th>
       <td><?php echo e($order->cantidad); ?></td>
    </tr>
    <tr height="50">
       <th>Variante ML4</th>
       <td><?php echo e($order->variante_ml4); ?></td>
    </tr>
    <tr height="50">
       <th>Fecha</th>
       <td><?php echo e($order->fecha); ?></td>
    </tr>
    <tr height="50">
       <th>Pedido Profit</th>
       <td><?php echo e($order->pedido_profit); ?></td>
    </tr>
    <tr height="50">
       <th>Estatus</th>
       <td><?php echo e($order->estatus); ?></td>
    </tr>

<?php if($order->fecha_pago): ?>

    <tr height="50">
       <th></th>
       <th>Datos Agregados</th>
    </tr>
    <tr height="50">
       <th>Despacho</th>
       <td><?php echo e($order->despacho); ?></td>
    </tr>
    <tr height="50">
       <th>Email</th>
       <td><?php echo e($order->email); ?></td>
    </tr>
    <tr height="50">
       <th>Articulo segun Cliente</th>
       <td><?php echo e($order->articulo_cliente); ?></td>
    </tr>
    <tr height="50">
       <th>Articulos Adicionales</th>
       <td><?php echo e($order->otros_articulos); ?></td>
    </tr>
    <tr height="50">
       <th>Cantidad segun Cliente</th>
       <td><?php echo e($order->cantidad_cliente); ?></td>
    </tr>
    <tr height="50">
       <th></th>
       <th>Datos Pago</th>
    </tr>
    <tr height="50">
       <th>Fecha</th>
       <td><?php echo e($order->fecha_pago); ?></td>
    </tr>
    <tr height="50">
       <th>Banco</th>
       <td><?php echo e($order->banco); ?></td>
    </tr>
    <tr height="50">
       <th>Banco Origen</th>
       <td><?php echo e($order->interbancario); ?></td>
    </tr>
    <tr height="50">
       <th>Monto</th>
       <td><?php echo e($order->monto_pago); ?></td>
    </tr>
    <tr height="50">
       <th>Referencia</th>
       <td><?php echo e($order->referencia_pago); ?></td>
    </tr>
    <tr height="50">
       <th>Transferencias Adicionales</th>
       <td><?php echo e($order->otros_pagos); ?></td>
    </tr>
    <tr height="50">
       <th>Factura Profit</th>
       <td><?php echo e($order->factura_profit); ?></td>
    </tr>

<?php endif; ?>

<?php if($order->destinatario): ?>

    <tr height="50">
       <th></th>
       <th>Datos Envio</th>
    </tr>
    <tr height="50">
       <th>Nombre Destinatario</th>
       <td><?php echo e($order->destinatario); ?></td>
    </tr>
    <tr height="50">
       <th>Nro Cedula</th>
       <td><?php echo e($order->cedula); ?></td>
    </tr>
    <tr height="50">
       <th>Telefono</th>
       <td><?php echo e($order->telefono); ?></td>
    </tr>
    <tr height="50">
       <th>Direccion</th>
       <td><?php echo e($order->direccion_envio); ?></td>
    </tr>
    <tr height="50">
       <th>Ciudad / Estado</th>
       <td><?php echo e($order->ciudad_envio); ?></td>
    </tr>
    <tr height="50">
       <th>Guia Envio</th>
       <td><?php echo e($order->guia_envio); ?></td>
    </tr>
    
<?php endif; ?>

</table><br/>

<div>
<table style="margin: 0 auto;">
   <tr>
      <?php if($order->destinatario): ?>
      <td><input type ='button' class="btn btn-warning"  value = 'Editar Envio' onclick="location.href = '<?php echo e(route('orders.shipedit', $order->pedidos_id)); ?>'"/></th>
      <?php endif; ?>
      <td><input type ='button' class="btn btn-warning"  value = 'Editar Pedido' onclick="location.href = '<?php echo e(route('orders.edit', $order->pedidos_id)); ?>'"/></th>
   </tr>
</table><br/>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>