

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('orders.index', 'Regresar')); ?>

</div>

Datos Generales

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table width="500" border="1" style="margin: 0 auto;">

    <tr height="50">
       <th>Id</th>
       <td><?php echo e($order->pedidos_id); ?></td>
    </tr>
    <tr height="50">
       <th>Nro Oferta</th>
       <td><?php echo e($order->codigo_venta); ?></td>
    </tr>
    <tr height="50">
       <th>Seudonimo</th>
       <td><?php echo e($order->seudonimo); ?></td>
    </tr>
    <tr height="50">
       <th>Nombre</th>
       <td><?php echo e($order->nombre); ?></td>
    </tr>
    <tr height="50">
       <th>Telefono</th>
       <td><?php echo e($order->telefono); ?></td>
    </tr>
    <tr height="50">
       <th>Ubicacion</th>
       <td><?php echo e($order->ubicacion); ?></td>
    </tr>
    <tr height="50">
       <th>Articulo</th>
       <td><?php echo e($order->titulo_publicacion); ?></td>
    </tr>
    <tr height="50">
       <th>Codigo Profit</th>
       <td><?php echo e($order->codigo_profit); ?></td>
    </tr>
    <tr height="50">
       <th>Variacion</th>
       <td><?php echo e($order->variacion_nombre); ?></td>
    </tr>
    <tr height="50">
       <th>Costo</th>
       <td><?php echo e($order->costo); ?></td>
    </tr>
    <tr height="50">
       <th>Cantidad</th>
       <td><?php echo e($order->cantidad); ?></td>
    </tr>
    <tr height="50">
       <th>Variante ML4</th>
       <td><?php echo e($order->variante_ml4); ?></td>
    </tr>
    <tr height="50">
       <th>Fecha</th>
       <td><?php echo e($order->fecha); ?></td>
    </tr>
    <tr height="50">
       <th>Pedido Profit</th>
       <td><?php echo e($order->pedido_profit); ?></td>
    </tr>
    <tr height="50">
       <th>Estatus</th>
       <td><?php echo e($order->estatus); ?></td>
    </tr>
    
</table>

<br/>

<div>
<table>

<input type ='button' class="btn btn-warning"  value = 'Actualizar' onclick="location.href = '<?php echo e(route('orders.edit', $order->pedidos_id)); ?>'"/>

</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>