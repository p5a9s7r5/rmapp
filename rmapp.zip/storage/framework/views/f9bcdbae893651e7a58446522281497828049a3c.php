

<?php $__env->startSection("cabecera"); ?>

Estados de Cuenta

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table style="margin: 0 auto;">
<nav>
<tr height="50">
        <?php echo Form::model(Request::all(), ['action' => 'AdminBanksController@index', 'method' => 'GET', 'class' => 'form-inline']); ?>

    <th><?php echo Form::label('fecha1', 'Desde: '); ?></th>
    <th><?php echo Form::date('fecha1', ''); ?></th>
    <th><?php echo Form::label('fecha2', 'Hasta: '); ?></th>
    <th><?php echo Form::date('fecha2', now()); ?></th>
    <th><?php echo Form::label('tipo', 'Tipo: '); ?></th>
    <th><?php echo Form::select('tipo', ['' => 'Seleccione', 'Entrada' => 'Entrada', 'Salida' => 'Salida']); ?></th>
    <th><?php echo Form::label('banco', 'Banco: '); ?></th>
    <th><?php echo Form::select('banco', config('options.bancos'), ''); ?></th>
</tr>
<tr height="50">
    <th colspan="1"></th>
    <th colspan="3"><?php echo Form::text('busqueda', null, ['class' => 'buscador', 'placeholder' => 'Busqueda']); ?></th>
    <th colspan="2"><?php echo Form::submit('Buscar', ['class' => 'buscador']); ?></th>
    <th colspan="1"></th>
        <?php echo Form::close(); ?>

</tr>
</nav>
</table> <br/>


<div>
<table id="tabla1">
    <thead>
    <tr height="50">
       <th>Fecha</th>
       <th>Banco</th>
       <th>Descripcion</th>
       <th>Referencia</th>
       <th>Monto</th>
       <th>Tipo</th>
    </tr>
    </thead>
 
    <tbody>
    <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($line->fecha); ?></td>
             <td><?php echo e($line->banco); ?></td>
             <td><?php echo e($line->descripcion); ?></td>
             <td><?php echo e($line->referencia); ?></td>
             <td><?php echo e($line->monto); ?></td>
             <td><?php echo e($line->tipo); ?></td>
            </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>

<?php echo e($lines->appends(Request::all())->render()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/banks/index.blade.php ENDPATH**/ ?>