

<?php $__env->startSection("cabecera"); ?>

Administrador Pedidos ML

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table style="margin: 0 auto;">
<nav>
        <?php echo Form::model(Request::all(), ['action' => 'AdminOrdersController@index', 'method' => 'GET', 'class' => 'form-inline']); ?>

    <th><?php echo Form::label('estatus', 'Estatus'); ?></th>
    <th><?php echo Form::select('estatus', config('options.status')); ?></th>
    <th><?php echo Form::text('busqueda', null, ['class' => 'buscador', 'placeholder' => 'Busqueda']); ?></th>
    <th><?php echo Form::submit('Buscar', ['class' => 'buscador']); ?></th>
        <?php echo Form::close(); ?>

</nav>
</table> <br/>


<div>
<table id="tabla1">
    <thead>
    <tr height="50">
       <th>Id</th>
       <th>Nro Oferta</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Monto</th>
       <th>Estatus</th>
       <th>Pedido Profit</th>
       <th>Ver Datos</th>
    </tr>
    </thead>
 
    <tbody>
    <?php if($orders): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($order->pedidos_id); ?></td>
             <td><?php echo e($order->codigo_venta); ?></td>
             <td><?php echo e($order->seudonimo); ?></td>
             <td><?php echo e($order->nombre); ?></td>
             <td><?php echo e($order->titulo_publicacion); ?></td>
             <td><?php echo e($order->costo); ?></td>
             <td><?php echo e($order->estatus); ?></td>
             <td><?php echo e($order->pedido_profit); ?></td>
             <td><?php echo e(link_to_route('orders.show', 'Ver Datos', $order->pedidos_id)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>

<?php echo e($orders->appends(Request::all())->render()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>