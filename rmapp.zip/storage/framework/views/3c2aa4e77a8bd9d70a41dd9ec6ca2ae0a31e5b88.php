

<?php $__env->startSection("cabecera"); ?>

Administrador Pedidos ML

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>

<table>
<nav class="navbar navbar-light bg-light">
    <?php echo Form::open(['action' => 'AdminOrdersController@index', 'method' => 'GET', 'class' => 'form-inline']); ?>

    <?php echo Form::text('busqueda', null, ['class' => 'form-control mr-sm-2', 'placeholder' => 'Busqueda', 'aria-label' => 'Search']); ?></td>
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    <?php echo Form::close(); ?>

</nav>
</table> <br/>


<div>
<table width="1000" border="1" style="margin: 0 auto;">
    <thead>
    <tr height="50">
       <th>Id</th>
       <th>Nro Oferta</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Monto</th>
       <th>Pedido Profit</th>
       <th>Ver Datos</th>
    </tr>
    </thead>
 
    <tbody>
    <?php if($orders): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($order->pedidos_id); ?></td>
             <td><?php echo e($order->codigo_venta); ?></td>
             <td><?php echo e($order->seudonimo); ?></td>
             <td><?php echo e($order->nombre); ?></td>
             <td><?php echo e($order->titulo_publicacion); ?></td>
             <td><?php echo e($order->costo); ?></td>
             <td><?php echo e($order->pedido_profit); ?></td>
             <td><?php echo e(link_to_route('orders.show', 'Ver Datos', $order->pedidos_id)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>

<?php echo e($orders->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>