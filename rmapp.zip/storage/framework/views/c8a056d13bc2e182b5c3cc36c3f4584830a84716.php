

<?php $__env->startSection("cabecera"); ?>

<div class="volver">
<?php echo e(link_to_route('orders.index', 'Todos los Pedidos')); ?>

</div>

Pedidos por Procesar

<?php $__env->stopSection(); ?>


<?php $__env->startSection("general"); ?>


<div>
<table id="tabla1">
    <thead>
    <tr height="50">
       <th>Envio</th>
       <th>Destinatario</th>
       <th>Seudonimo</th>
       <th>Nombre</th>
       <th>Articulo</th>
       <th>Cantidad</th>
       <th>Otros Articulos</th>
       <th>Factura Profit</th>
       <th>Imprimir Guia</th>
    </tr>
    </thead>
 
    <tbody>
    <?php if($orders): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr height="50">
             <td><?php echo e($order->despacho); ?></td>
             <td><?php echo e($order->destinatario); ?></td>
             <td><?php echo e($order->seudonimo); ?></td>
             <td><?php echo e($order->nombre); ?></td>
             <td><?php echo e($order->titulo_publicacion); ?></td>
             <td><?php echo e($order->cantidad); ?></td>
             <?php if($order->otros_articulos): ?>
                <td>Si</td>
             <?php else: ?>
                <td>No</td>
             <?php endif; ?>
             <td><?php echo e($order->factura_profit); ?></td>
             <td><?php echo e(link_to_route('orders.pdfguide', 'Confirmar', $order->pedidos_id)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/rmapp/resources/views/admin/orders/shipping.blade.php ENDPATH**/ ?>